// routes/products.js

const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// Route for home page
router.get('/', productController.getAllProducts);

// Route for viewing a single product
router.get('/product/:id', productController.getProductById);

module.exports = router;
