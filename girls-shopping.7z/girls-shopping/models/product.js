// models/product.js

const products = require('../data/products.json');

// Get all products
exports.getAll = () => {
  return products;
};

// Get a product by its ID
exports.getById = (id) => {
  return products.find(product => product.id === id);
};
