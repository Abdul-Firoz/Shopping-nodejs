// controllers/productController.js

const Product = require('../models/product');

// Get all products
exports.getAllProducts = (req, res) => {
  const products = Product.getAll();
  res.render('index', { products });
};

// Get product by ID
exports.getProductById = (req, res) => {
  const productId = req.params.id;
  const product = Product.getById(productId);
  
  if (product) {
    res.render('product', { product });
  } else {
    res.status(404).send('Product not found');
  }
};
